#!/bin/bash

# DEPLOYMENT SETUP SCRIPT
# Run this script to copy deployment files to your local git repository

echo "🚀 Copying deployment files to your Git repository..."

# Create the client lib directory if it doesn't exist
mkdir -p client/src/lib

# Copy the API client
cp client/src/lib/api.ts client/src/lib/api.ts.bak 2>/dev/null || true
cp DEPLOYMENT_FILES_TO_PUSH/client/src/lib/api.ts client/src/lib/

# Copy configuration files
cp DEPLOYMENT_FILES_TO_PUSH/netlify.toml .
cp DEPLOYMENT_FILES_TO_PUSH/.env.netlify.example .
cp DEPLOYMENT_FILES_TO_PUSH/setup-netlify.sh .

# Copy documentation
cp DEPLOYMENT_FILES_TO_PUSH/INSTANT_DEPLOYMENT.md .
cp DEPLOYMENT_FILES_TO_PUSH/NETLIFY_DEPLOYMENT.md .
cp DEPLOYMENT_FILES_TO_PUSH/NETLIFY_CONFIG_SUMMARY.md .

# Backup and update package.json
cp package.json package.json.backup
cp DEPLOYMENT_FILES_TO_PUSH/package.updated.json package.json

# Backup and update server/index.ts
cp server/index.ts server/index.ts.backup
cp DEPLOYMENT_FILES_TO_PUSH/server.index.updated.ts server/index.ts

echo "✅ All deployment files copied successfully!"
echo ""
echo "Next steps:"
echo "1. Review the changes: git diff"
echo "2. Commit the changes: git add . && git commit -m 'Add complete Netlify deployment configuration'"
echo "3. Push to GitHub: git push origin main"
echo ""
echo "🚀 Your deployment is ready to go live!"