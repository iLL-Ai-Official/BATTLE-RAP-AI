#!/bin/bash

# Netlify Deployment Setup Script
# This script prepares the project for Netlify + Backend deployment

echo "🚀 Netlify Deployment Setup for RapBots AI"
echo "============================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Please run this script from the BATTLE-RAP-AI directory."
    exit 1
fi

print_status "Project structure verified"

# Check if netlify.toml exists
if [ ! -f "netlify.toml" ]; then
    print_error "netlify.toml not found. Please ensure you have the Netlify configuration file."
    exit 1
fi

print_status "Netlify configuration found"

# Check if .env.netlify.example exists
if [ ! -f ".env.netlify.example" ]; then
    print_error ".env.netlify.example not found."
    exit 1
fi

print_status "Environment template found"

echo ""
echo "📋 Next Steps:"
echo "=============="
echo ""
print_info "1. BACKEND DEPLOYMENT:"
echo "   Choose one of these options:"
echo "   - Railway: https://railway.app (Recommended)"
echo "   - Render: https://render.com" 
echo "   - Heroku: https://heroku.com"
echo ""
print_info "2. FRONTEND DEPLOYMENT (Netlify):"
echo "   - Connect your GitHub repository to Netlify"
echo "   - Set build command: 'npm run build'"
echo "   - Set publish directory: 'dist'"
echo ""
print_info "3. ENVIRONMENT VARIABLES:"
echo ""
echo "   Frontend (.env for Netlify):"
echo "   ==========================="
echo "   VITE_API_BASE_URL=https://your-backend-url.railway.app/api"
echo ""
echo "   Backend (Railway/Render/Heroku):"
echo "   ==============================="
echo "   DATABASE_URL=postgresql://user:pass@host:port/db"
echo "   SESSION_SECRET=your_secure_session_secret"
echo "   GROQ_API_KEY=your_groq_api_key"
echo "   ELEVENLABS_API_KEY=your_elevenlabs_api_key"
echo "   OPENAI_API_KEY=your_openai_api_key"
echo "   NODE_ENV=production"
echo ""

# Create .env.netlify if it doesn't exist
if [ ! -f ".env.netlify" ]; then
    cp .env.netlify.example .env.netlify
    print_status "Created .env.netlify file from template"
    print_warning "Please edit .env.netlify with your backend URL before deployment"
else
    print_info ".env.netlify already exists"
fi

echo ""
print_info "4. CORS Configuration:"
echo "   The backend has been configured with CORS support."
echo "   After deploying backend, you may need to add your Netlify domain"
echo "   to the allowed origins in server/index.ts"
echo ""

print_info "5. Testing:"
echo "   After deployment, test these endpoints:"
echo "   - Backend health: https://your-backend-url/api/health"
echo "   - Frontend site: https://your-site.netlify.app"
echo ""

print_status "Setup complete! Follow the deployment guide in NETLIFY_DEPLOYMENT.md"

echo ""
echo "📚 Documentation:"
echo "   - NETLIFY_DEPLOYMENT.md - Complete deployment guide"
echo "   - .env.netlify.example - Frontend environment template"
echo "   - netlify.toml - Netlify build configuration"
echo ""

print_info "For detailed instructions, see NETLIFY_DEPLOYMENT.md"