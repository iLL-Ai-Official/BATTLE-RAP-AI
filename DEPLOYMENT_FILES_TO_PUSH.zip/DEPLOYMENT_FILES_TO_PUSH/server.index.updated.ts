import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { challengeRotationService } from "./services/challengeRotation";
import path from "path";
import fs from "fs";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// CORS configuration for Netlify deployment
const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (mobile apps, etc.)
    if (!origin) return callback(null, true);
    
    const allowedOrigins = [
      'http://localhost:3000',
      'http://localhost:5000', 
      'http://localhost:5173',
      'https://localhost:3000',
      'https://localhost:5000',
      'https://localhost:5173',
      // Add your Netlify domain here after deployment
      // 'https://your-site.netlify.app'
    ];
    
    // In production, you can also set this from environment variable
    const netlifyDomain = process.env.NETLIFY_DOMAIN;
    if (netlifyDomain) {
      allowedOrigins.push(`https://${netlifyDomain}`);
      allowedOrigins.push(`https://${netlifyDomain}.netlify.app`);
    }
    
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
};

app.use(cors(corsOptions));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Production environment validation
  if (process.env.NODE_ENV === 'production') {
    console.log('🚀 Production deployment detected');
    
    // Validate critical environment variables
    const requiredEnvVars = ['DATABASE_URL', 'SESSION_SECRET'];
    const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
    
    if (missingVars.length > 0) {
      console.error('❌ Missing required environment variables:', missingVars);
      console.error('💡 Set these in your deployment environment');
    } else {
      console.log('✅ Required environment variables present');
    }
    
    // Check optional AI service keys
    const hasGroq = !!process.env.GROQ_API_KEY;
    const hasOpenAI = !!process.env.OPENAI_API_KEY;
    console.log(`🤖 AI Services: Groq ${hasGroq ? '✅' : '❌'}, OpenAI ${hasOpenAI ? '✅' : '❌'}`);
    
    if (!hasGroq && !hasOpenAI) {
      console.warn('⚠️ No AI service keys found - app functionality will be limited');
    }
  }

  // Serve static assets from attached_assets directory
  app.use('/attached_assets', express.static(path.resolve(import.meta.dirname, '..', 'attached_assets')));

  const server = await registerRoutes(app);

  challengeRotationService.start();
  console.log('🔄 Daily challenges rotation service started');

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error(`Server error ${status}:`, err);
    res.status(status).json({ message });

    // Don't throw in production to prevent server crashes
    if (app.get("env") === "development") {
      console.error("Development error details:", err);
    }
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  
  // Robust production detection: Default to production if build exists
  // This ensures deployment works even if NODE_ENV isn't set
  const distPublicPath = path.resolve(import.meta.dirname, "public");
  const buildExists = fs.existsSync(distPublicPath) && 
                      fs.existsSync(path.join(distPublicPath, "index.html"));
  
  // Use dev mode ONLY if explicitly running tsx (development)
  // Otherwise if build exists, use production mode
  const isDevelopment = process.env.NODE_ENV === "development" || 
                        (!buildExists && process.env.NODE_ENV !== "production");
  
  if (isDevelopment) {
    console.log('🔧 Development mode: Starting Vite dev server');
    console.log(`   Reason: NODE_ENV=${process.env.NODE_ENV}, build_exists=${buildExists}`);
    await setupVite(app, server);
  } else {
    console.log('🏭 Production mode: Serving pre-built static files from dist/public');
    console.log(`   Reason: NODE_ENV=${process.env.NODE_ENV}, build_exists=${buildExists}`);
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  
  // Always bind to 0.0.0.0 for Replit Autoscale deployments
  // Binding to 127.0.0.1 prevents external traffic routing
  const host = process.env.HOST || '0.0.0.0';

  server.listen(port, host, () => {
    log(`serving on ${host}:${port}`);
  });
})();