# Netlify + Backend Deployment Guide

## Architecture Overview

This application is split into two main components:
1. **Frontend**: React/Vite app deployed to Netlify (static hosting)
2. **Backend**: Node.js/Express API deployed to a backend service

## Prerequisites

- Netlify account
- Backend service account (Railway, Render, Heroku, or DigitalOcean)
- Git repository with the deployed code

## Part 1: Deploy Backend Service

### Option A: Railway (Recommended)

1. **Connect GitHub Repository**
   - Go to [railway.app](https://railway.app)
   - Connect your GitHub repository
   - Select the `BATTLE-RAP-AI` repository

2. **Configure Environment Variables**
   - In Railway dashboard, add these environment variables:
   ```
   DATABASE_URL=postgresql://your_db_connection_string
   SESSION_SECRET=your_secure_session_secret
   GROQ_API_KEY=your_groq_api_key
   ELEVENLABS_API_KEY=your_elevenlabs_api_key
   OPENAI_API_KEY=your_openai_api_key
   NODE_ENV=production
   PORT=5000
   ```

3. **Deploy**
   - Railway will automatically detect the `package.json` and deploy
   - Note the generated URL (e.g., `https://your-app.railway.app`)

### Option B: Render

1. **Create New Web Service**
   - Go to [render.com](https://render.com)
   - Connect GitHub repository
   - Choose "Web Service"

2. **Configuration**
   - **Build Command**: `npm ci && npm run build`
   - **Start Command**: `npm start`
   - **Environment**: Node

3. **Environment Variables** (same as Railway)

4. **Deploy** and note the URL

### Option C: Heroku

1. **Create App**
   ```bash
   heroku create your-app-name
   ```

2. **Add PostgreSQL**
   ```bash
   heroku addons:create heroku-postgresql:mini
   ```

3. **Set Environment Variables**
   ```bash
   heroku config:set SESSION_SECRET=your_secret
   heroku config:set GROQ_API_KEY=your_groq_key
   # ... other variables
   ```

4. **Deploy**
   ```bash
   git push heroku main
   ```

## Part 2: Deploy Frontend to Netlify

### Method A: GitHub Integration (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Configure for Netlify deployment"
   git push origin main
   ```

2. **Connect to Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Click "New site from Git"
   - Connect GitHub and select your repository

3. **Build Settings**
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
   - **Node version**: `20`

4. **Environment Variables**
   - Go to Site Settings > Environment Variables
   - Add: `VITE_API_BASE_URL=https://your-backend-url.railway.app/api`

5. **Deploy**
   - Click "Deploy site"
   - Netlify will automatically build and deploy

### Method B: Manual Drag & Drop

1. **Build Locally**
   ```bash
   # Install dependencies
   npm install
   
   # Create .env file
   cp .env.netlify.example .env
   # Edit .env with your backend URL
   
   # Build
   npm run build
   ```

2. **Deploy**
   - Go to [netlify.com](https://netlify.com)
   - Drag and drop the `dist` folder to the deploy area

### Method C: Netlify CLI

1. **Install CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Login and Deploy**
   ```bash
   netlify login
   netlify deploy --prod --dir=dist
   ```

## Part 3: Configure Environment Variables

### Frontend (.env for Netlify)
```
VITE_API_BASE_URL=https://your-backend-url.railway.app/api
```

### Backend (Service Platform)
```
DATABASE_URL=postgresql://user:pass@host:port/db
SESSION_SECRET=your_very_secure_secret
GROQ_API_KEY=your_groq_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
OPENAI_API_KEY=your_openai_api_key
NODE_ENV=production
PORT=5000
```

## Part 4: Update Frontend Code

If your backend is already deployed, you need to update the API configuration:

1. **Check Current API Usage**
   - The frontend uses relative API calls like `/api/auth/user`
   - This needs to be updated to use the full backend URL

2. **Update API Calls**
   - The `client/src/lib/api.ts` file should already be configured
   - If not, update API endpoints to use the backend URL

3. **Update Environment**
   - Set `VITE_API_BASE_URL` in Netlify environment variables

## Part 5: Testing the Deployment

1. **Check Backend Health**
   - Visit: `https://your-backend-url.railway.app/api/health`
   - Should return: `{ "status": "ok" }`

2. **Test Frontend**
   - Visit your Netlify site URL
   - Check browser console for any CORS or API errors
   - Test user registration/login functionality

## Part 6: Custom Domain (Optional)

### Backend Domain
1. In your backend service (Railway/Render), add a custom domain
2. Update Netlify environment variable with new domain

### Frontend Domain
1. In Netlify, go to Domain Settings
2. Add custom domain (e.g., `yourapp.com`)
3. Follow DNS configuration instructions

## Troubleshooting

### CORS Issues
- Ensure backend has CORS configured for your Netlify domain
- Backend CORS should allow requests from `https://your-site.netlify.app`

### API Connection Issues
- Check that `VITE_API_BASE_URL` is correctly set
- Verify backend is running and accessible
- Check browser Network tab for failed requests

### Build Failures
- Ensure Node.js version is set to 20 in Netlify
- Check build logs in Netlify dashboard
- Verify all environment variables are set

## Production Checklist

- [ ] Backend deployed and accessible
- [ ] Frontend deployed to Netlify
- [ ] Environment variables configured
- [ ] CORS properly configured
- [ ] Health check endpoints working
- [ ] Authentication flow tested
- [ ] Database migrations completed
- [ ] SSL certificates configured (automatic with Netlify)

## Next Steps

After successful deployment:
1. Set up monitoring and logging
2. Configure automated backups
3. Set up CI/CD pipeline
4. Add custom domain
5. Configure analytics